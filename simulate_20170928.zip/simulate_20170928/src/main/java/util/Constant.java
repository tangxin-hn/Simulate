package util;

/**
 * Created by Zhao Zhe on 2017/9/12.
 * 常量：1除以根号2
 */
public class Constant {
    public static final double SQURT2 = 1.0/Math.sqrt(2);
}
